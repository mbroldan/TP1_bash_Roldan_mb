#!/bin/bash

cat $LISTADO_ALUMNO > /home/EPNro1/procesado/LISTADO_ALUMNO.txt    #copia la lista de alumnos y la pega en la carpeta procesado
cd /home/EPNro1/procesado
cp LISTADO_ALUMNO.txt /home/EPNro1/salida/LISTADO_ALUMNO_MODIFICADO.txt

cd /home/EPNro1/entrada
cat * >> /home/EPNro1/salida/LISTADO_ALUMNO_MODIFICADO.txt   #lee todos los archivos en la carpeta entrada y los copia y pega en el archivo modificado
