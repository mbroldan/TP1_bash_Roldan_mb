#!/bin/bash
LISTADO_ALUMNO=$1     #Almacena el primer elemento puesto después del bash TP1_... en una variable
export LISTADO_ALUMNO
#para ejecutar bien el programa hay que hacer bash TP1_ROLDAN_MARTIN_BERNARDO.sh LISTADO_ALUMNO.txt
echo "-----MENU-----"
echo "1_Crear entorno"
echo "2_Crear proceso"
echo "3_Listado de alumnos"
echo "4_Notas más altas"
echo "5_Datos de alumno específico"
echo "6_Salir"
echo "-d_Borrar carpeta"
RUTA=$(pwd)      #Guarda la ruta donde se ejecuta el programa

until [[ $OPCION_MENU -eq 6 ]] do
	echo "Ignrese la opcion del menu"
	read OPCION_MENU
	cd "$RUTA"
	case $OPCION_MENU in
	1)
		cd /home
		sudo mkdir EPNro1
		cd EPNro1
		sudo mkdir entrada
		sudo mkdir salida
		sudo mkdir procesado
		echo "carpetas creadas exitosamente";;
	2)
		sudo cp consolidar.sh /home/EPNro1
		cd /home/EPNro1
		sudo bash consolidar.sh $LISTADO_ALUMNO
		echo "creaste el archivo modificado";;
	3)
		cd /home/EPNro1/salida
		if [ -f $LISTADO_ALUMNO_MODIFICADO ]; then
			sort -n LISTADO_ALUMNO_MODIFICADO.txt
		else
			echo "No tenés ninguna lista"
		fi;;
	4)
		cd /home/EPNro1/salida
		if [ -f $LISTADO_ALUMNO_MODIFICADO ]; then
#-t indica que se toma como columnas separadas por lo que va entre parentesis, y el -k infica la columna
			sort -t " " -n -r -k5,5 LISTADO_ALUMNO_MODIFICADO.txt | head 
		else
			echo "No tenés ninguna lista"
		fi;;
	5)
		cd /home/EPNro1/salida
		echo "Ingresa un padrón"
		read PADRON < /dev/tty
		if [[ "$PADRON" =~ ^[0-9]{5,6}$ ]]; then      #indica que el padron dado solo puede empezar por 6 digitos
			grep "$PADRON" LISTADO_ALUMNO_MODIFICADO.txt
		else
			echo "Padron no encontrado"
		fi;;
	6)
		echo "saliste del programa";;
	"-d")
		sudo rm -rf /home/EPNro1
		kill -9 -1;; #elimina todos los procesos
	*)
		echo "No elegiste ninguna opción, vuelva a ingresar";;
	esac < $LISTADO_ALUMNO
done

